This is a freeware game by "4-tuple".
It is a curtain-fire shooting game.

-------------------
System requirements
-------------------

-~8MB? RAM
-However much disk space
-Operating System: Windows XP or newer (Will probably run on other or older OSs, but untested)
-Processor, x86 32-bit, 1.86 GHz or more? (Will probably run on less, HiScore screen might be laggy)





-----
Story
-----

"ROBOT DRAGON" came from space and is threatening Earth. It has capacity beyond conventional weapons and cannot be stopped.
Earth created the new super-advanced combat space ship "TORNADO" in a desperate move to stop "ROBOT DRAGON".
You are the pilot of "TORNADO". 
"ROBOT DRAGON" is approaching fast! You must fight bravely to defeat "ROBOT DRAGON" and save Earth. All of our hopes and dreams rest on you and "TORNADO"!

-----------
How to play
-----------

To start the game, simply run "game.exe".

The game is controlled mostly with the arrow keys, Z key, and X key. Z key is select on menus / hiscore entry, X key is cancel. ESC is also cancel, and ENTER is also select. SHIFT can be used to slow down the speed at which the hiscore entry cursor moves.

In play, these are the controls.
Arrow Keys...Movement
Hold Z.......Lightningbolt shot (while held)
Push X.......Stormfront Shield (tap, 3 per life)
Hold LSHIFT..Switch to maneuvering engines (while held)
ESC..........Abort Mission (return to title screen)

The TORNADO's vital cross-section (or hitbox) is extremely small, much smaller than the TORNADO itself. It is precisely in the center of the TORNADO's sprite. If and only if the TORNADO is struck in its vital cross section, it will be destroyed. Glanncing blows are ineffective against "TORNADO".
The Stormfront Shield will erase bullets and make you briefly invincible, but it has limited uses (3 per life) and cannot affect "ROBOT DRAGON".

When an enemy is destroyed, it will drop a point item. Collect this to increase your score. The higher on the screen you are, the more score a point item will give. Destroying enemies also gives you a small number of points.
In addition, if you defeat "ROBOT DRAGON", you will gain a large number of points, and more points for lives and bombs you have remaining.

This is all of the help you get. Fight bravely to protect the Earth!!